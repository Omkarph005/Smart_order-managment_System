
# Smart Order Management System

A complete Spring Boot REST API project covering Core Java and Spring Boot concepts.

## Concepts Covered
- OOP (Encapsulation)
- Java Collections & ConcurrentHashMap
- Exception Handling
- Spring Boot REST APIs
- CRUD Operations
- Thread Safety

## Endpoints
POST /orders
GET /orders/{id}
GET /orders
PUT /orders/{id}
DELETE /orders/{id}

## Run
mvn spring-boot:run
